function handleFormSubmit(event) {
    event.preventDefault();
    alert('Form submitted successfully!');
    event.target.reset();
}
document.addEventListener("DOMContentLoaded", function() {
    const container = document.querySelector('.container');
    container.style.animationPlayState = 'running';
});